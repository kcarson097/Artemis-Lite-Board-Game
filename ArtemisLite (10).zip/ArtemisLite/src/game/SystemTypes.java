package game;

public enum SystemTypes {
	
	RESEARCH,GROUND_SYSTEMS,LUNAR_EXPLORATION,SATELITES_SUPPORT;

}
