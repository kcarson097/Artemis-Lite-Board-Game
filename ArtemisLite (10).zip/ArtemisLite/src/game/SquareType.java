package game;

public enum SquareType {
	
	SPACE_LAUNCH_HQ,DEEP_SPACE,CHANCE,SYSTEM;

}
